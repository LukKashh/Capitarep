CAPITAL FORTUNE — VISUAL REFERENCE ASSET PACKS

This archive contains the 10 supplied Capital Fortune reference sheets.

Contents:
01. Core Branding & Game Assets
02. Business Buildings & Upgrade Variations
03. Real Estate & Luxury Assets
04. Financial Markets & Investments
05. Corporation, Business Management & Research
06. User Profiles, Achievements, Tasks & Progression
07. Game Environments, Backgrounds & UI Textures
08. Financial Items, Currency & Rewards
09. Complete Mobile UI Screens & Navigation
10. Complete UI Component Library

These are reference sheets, not pre-sliced individual production assets.
Inspect each sheet and identify/crop individual reusable elements before integrating them.
Preserve the original reference images.
